# Research & Analysis Subagents

Research & Analysis subagents are your investigative powerhouses, specializing in finding, analyzing, and synthesizing information from diverse sources. These experts excel at deep research, competitive intelligence, market analysis, and trend identification. They transform raw information into actionable insights, helping you make informed decisions based on comprehensive analysis and data-driven research.

## When to Use Research & Analysis Subagents

Use these subagents when you need to:
- **Conduct comprehensive research** on any topic
- **Find specific information** across multiple sources
- **Analyze market dynamics** and opportunities
- **Track competitive intelligence** systematically
- **Identify emerging trends** before others
- **Gather and analyze data** for insights
- **Synthesize complex information** into clear findings
- **Make data-driven decisions** with confidence

## Available Subagents

### [**ab-test-analysis**](ab-test-analysis.md) - A/B test analysis and ship/no-ship decision specialist
Statistical analysis expert interpreting A/B test results, p-values, confidence intervals, and effect sizes. Makes principled ship/no-ship decisions using a structured framework and catches common analysis errors like peeking, multiple comparisons, and Simpson's Paradox.

**Use when:** Analyzing A/B or experiment results, interpreting p-values, making ship or no-ship decisions, evaluating statistical vs. practical significance, or validating test integrity.

### [**cohort-analysis**](cohort-analysis.md) - User cohort retention and behavioral analysis specialist
Retention analysis expert understanding how user groups behave over time. Diagnoses retention curve shapes, identifies activation metrics (the "Aha Moment"), and tracks whether product improvements are actually moving retention numbers.

**Use when:** Analyzing user retention, diagnosing where the retention curve drops, finding activation behaviors, comparing cohort performance over time, or assessing product-market fit signals.

### [**first-principles-thinking**](first-principles-thinking.md) - First principles problem-solving specialist
Strategic thinking specialist breaking complex problems down to irreducible truths and rebuilding solutions from scratch. Applies the 5-step first principles method and 5D structured problem-solving framework to cut through assumptions.

**Use when:** Challenging why things are done a certain way, rethinking a product or process from scratch, solving a recurring problem that conventional approaches haven't fixed, or pressure-testing assumptions before committing to a solution.

### [**research-analyst**](research-analyst.md) - Comprehensive research specialist
Research expert conducting thorough investigations across domains. Masters research methodologies, source validation, and insight synthesis. Delivers comprehensive research reports on any topic.

**Use when:** Conducting deep research, investigating complex topics, validating information, creating research reports, or synthesizing multiple sources.

### [**search-specialist**](search-specialist.md) - Advanced information retrieval expert
Search optimization expert finding needles in information haystacks. Masters advanced search techniques, query optimization, and source discovery. Locates hard-to-find information efficiently.

**Use when:** Finding specific information, optimizing search queries, discovering new sources, conducting systematic searches, or retrieving obscure data.

### [**trend-analyst**](trend-analyst.md) - Emerging trends and forecasting expert
Trend identification specialist spotting patterns before they become obvious. Expert in trend analysis, future forecasting, and weak signal detection. Helps organizations stay ahead of change.

**Use when:** Identifying emerging trends, forecasting future developments, analyzing pattern changes, monitoring industry evolution, or planning strategic responses.

### [**competitive-analyst**](competitive-analyst.md) - Competitive intelligence specialist
Competitive intelligence expert analyzing competitor strategies and market positioning. Masters competitive benchmarking, SWOT analysis, and strategic recommendations. Provides actionable competitive insights.

**Use when:** Analyzing competitors, benchmarking performance, identifying competitive advantages, monitoring competitor moves, or developing competitive strategies.

### [**market-researcher**](market-researcher.md) - Market analysis and consumer insights
Market analysis specialist understanding market dynamics and consumer behavior. Expert in market sizing, segmentation, and opportunity identification. Reveals market opportunities and risks.

**Use when:** Analyzing market opportunities, understanding consumer behavior, sizing markets, identifying segments, or evaluating market entry strategies.

### [**project-idea-validator**](project-idea-validator.md) - Brutal go or no-go idea validator
Adversarial product idea specialist pressure-testing concepts against competitors, demand signals, and adoption friction. Focuses on killing weak ideas early and sharpening strong ones into evidence-backed MVPs.

**Use when:** Stress-testing a startup or product idea, checking whether differentiation is real, finding hidden competitors, deciding whether to pivot, or getting a clear go/no-go recommendation before building.

### [**data-researcher**](data-researcher.md) - Data discovery and analysis expert
Data investigation specialist extracting insights from complex datasets. Masters data mining, statistical analysis, and pattern recognition. Transforms raw data into meaningful findings.

**Use when:** Analyzing datasets, discovering data patterns, performing statistical analysis, mining for insights, or investigating data anomalies.

### [**scientific-literature-researcher**](scientific-literature-researcher.md) - Scientific paper search and evidence synthesis
Scientific literature specialist using [BGPT MCP](https://github.com/connerlambden/bgpt-mcp) to search a database of papers with structured experimental data extracted from full-text studies. Retrieves methods, results, sample sizes, and quality scores to deliver evidence-grounded analysis.

**Use when:** Searching scientific literature, conducting systematic reviews, synthesizing experimental evidence, fact-checking claims against published data, or building evidence-grounded research reports.

## Quick Selection Guide

| If you need to... | Use this subagent |
|-------------------|-------------------|
| Analyze A/B test results | **ab-test-analysis** |
| Analyze user retention | **cohort-analysis** |
| Challenge assumptions from scratch | **first-principles-thinking** |
| Deep topic research | **research-analyst** |
| Find specific information | **search-specialist** |
| Identify future trends | **trend-analyst** |
| Analyze competitors | **competitive-analyst** |
| Understand markets | **market-researcher** |
| Pressure-test product ideas | **project-idea-validator** |
| Analyze data patterns | **data-researcher** |
| Search scientific papers | **scientific-literature-researcher** |

## Common Research Patterns

**Market Intelligence:**
- **market-researcher** for market analysis
- **competitive-analyst** for competitor insights
- **trend-analyst** for future directions
- **data-researcher** for data validation

**Strategic Research:**
- **research-analyst** for comprehensive analysis
- **search-specialist** for information gathering
- **trend-analyst** for future planning
- **competitive-analyst** for positioning

**Idea Validation:**
- **project-idea-validator** for go/no-go product scrutiny
- **competitive-analyst** for direct rival teardown
- **market-researcher** for market context
- **trend-analyst** for demand timing

**Data-Driven Insights:**
- **data-researcher** for data analysis
- **market-researcher** for market data
- **trend-analyst** for pattern identification
- **research-analyst** for synthesis

**Competitive Intelligence:**
- **competitive-analyst** for competitor analysis
- **market-researcher** for market context
- **search-specialist** for information discovery
- **trend-analyst** for industry evolution

## Getting Started

1. **Define research objectives** clearly
2. **Choose appropriate specialists** for your needs
3. **Provide context and constraints** for focused research
4. **Validate findings** through multiple sources
5. **Apply insights** to decision-making

## Best Practices

- **Start with clear questions:** Focus drives better research
- **Use multiple sources:** Single sources can mislead
- **Validate information:** Trust but verify
- **Document methodology:** Research should be reproducible
- **Consider biases:** All sources have perspectives
- **Synthesize findings:** Raw data needs interpretation
- **Update regularly:** Research has expiration dates
- **Share insights:** Knowledge multiplies when shared

Choose your research & analysis specialist and make better decisions today!
